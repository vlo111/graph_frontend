export const GRAPH_STATUS = [
  { value: 'active', label: 'Active' },
  { value: 'draft', label: 'Draft' },
];
