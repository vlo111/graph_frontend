export const friendType = {
  pending: 'pending',
  accepted: 'accepted',
  rejected: 'rejected',
};
