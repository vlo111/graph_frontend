export const DEFAULT_FILTERS = {
  hideIsolated: '',
  nodeTypes: [],
  linkTypes: [],
  nodeKeywords: [],
  nodeCustomFields: [],
  labels: [],
  linkValue: {
    min: -1,
    max: -1,
  },
  linkConnection: {
    min: -1,
    max: -1,
  },
};
