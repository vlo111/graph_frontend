

export function getGraphsEmbedLabel()
