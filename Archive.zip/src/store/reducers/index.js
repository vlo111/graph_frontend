import { combineReducers } from 'redux';
import app from './app';
import account from './account';
import graphs from './graphs';
import shareGraphs from './shareGraphs';
import commentGraphs from './commentGraphs';
import notifications from './notifications';
import userFriends from './userFriends';
import profile from './profile';
import graphLabelsEmbed from './graphLabelsEmbed';

export default combineReducers({
  app,
  account,
  graphs,
  shareGraphs,
  commentGraphs,
  notifications,
  userFriends,
  profile,
  graphLabelsEmbed,
});
