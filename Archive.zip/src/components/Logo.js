import React, { Component } from 'react';

class Logo extends Component {
  render() {
    return (
      <div   id="logo">
        Graphs
      </div>
    );
  }
}

export default Logo;
