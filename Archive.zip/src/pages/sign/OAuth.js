import { Component } from 'react';

class OAuth extends Component {
  render() {
    return null;
  }
}

export default OAuth;
